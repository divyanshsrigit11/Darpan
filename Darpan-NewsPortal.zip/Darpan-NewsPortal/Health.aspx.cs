﻿using System.Web.UI;
using System;

namespace Darpan
{
    public partial class Health : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // No specific server-side logic needed for a static "No Content" page.
        }
    }
}