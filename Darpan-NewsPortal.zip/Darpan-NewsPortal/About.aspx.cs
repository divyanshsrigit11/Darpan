﻿using System;
using System.Web.UI;

namespace Darpan
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // No specific server-side logic needed for a static "No Content" page.
        }
    }
}