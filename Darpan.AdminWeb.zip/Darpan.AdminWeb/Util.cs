﻿using System;
using System.Data;

namespace Darpan.AdminWeb
{
    internal class Util
    {
        internal DataSet GetUserDashboard()
        {
            throw new NotImplementedException();
        }
    }
}